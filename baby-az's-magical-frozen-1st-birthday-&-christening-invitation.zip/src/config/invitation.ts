/**
 * Baby AZ's Magical Frozen 1st Birthday & Christening Central Configuration
 * All text, images, dates, locations, and settings are centrally managed here.
 */

export interface ScheduleItem {
  time: string;
  title: string;
  description: string;
  location: string;
  iconType: 'church' | 'camera' | 'car' | 'party';
}

export interface GalleryPhoto {
  id: string;
  url: string;
  title: string;
  caption: string;
}

export interface WishlistItem {
  id: string;
  name: string;
  category: string;
  description: string;
  sizeOrSpecs?: string;
  price?: string;
  storeName?: string;
  shoppingUrl?: string;
  iconEmoji?: string;
}

// 8 Real photographs of Baby AZ
export const BABY_GALLERY_PHOTOS = [
  "/images/gallery/baby-az-01.jpg", // 1. az rawr.jpg – Blue tutu outfit
  "/images/gallery/baby-az-02.jpg", // 2. Az cute.jpg – Baby AZ with a book
  "/images/gallery/baby-az-03.jpg", // 3. Az red.jpg – Baby AZ smiling in red
  "/images/gallery/baby-az-04.jpg", // 4. az pretty.jpg – Baby AZ in crocheted outfit
  "/images/gallery/baby-az-05.jpg", // 5. az snowwhite.jpg – Baby AZ in Snow White costume
  "/images/gallery/baby-az-06.jpg", // 6. az ramen.jpg – Baby AZ smiling in pink
  "/images/gallery/baby-az-07.jpg", // 7. az back.jpg – Baby AZ outdoors near the pool
  "/images/gallery/baby-az-08.jpg", // 8. az rrff.jpg – Baby AZ smiling with turquoise hair accessories
];

export const INVITATION_CONFIG = {
  baby: {
    fullName: "Avryl Zaliyah",
    nickname: "Baby AZ",
    heroPhoto: "/images/baby-az-hero.jpg",
    portraitUrl: "/images/baby-az-hero.jpg",
    galleryPhotos: BABY_GALLERY_PHOTOS,
    milestone: "1st Birthday & Christening",
    headline: "A LITTLE SNOW PRINCESS TURNS ONE",
    birthdateSubtitle: "One Year of Magical Smiles & Pure Joy",
    parents: {
      mommy: "Mommy Chaye",
      daddy: "Daddy Jerome",
      signature: "Mommy Chaye & Daddy Jerome",
    },
    welcomeMessage:
      "Our little snow princess is turning ONE! With hearts full of love and gratitude, we are also celebrating the beautiful blessing of her Christening. Join us for a magical day of love, laughter, and unforgettable memories.",
    closingMessage: "Thank You for Being Part of Our Story",
    closingSubtext: "With love, Baby AZ & Family.",
  },

  // Alias for backward compatibility
  get celebrant() {
    return this.baby;
  },

  eventDate: {
    displayDate: "Saturday, December 5, 2026",
    dayOfWeek: "Saturday",
    fullDateString: "December 5, 2026",
    // Countdown target in Asia/Manila (UTC+8)
    countdownTargetIso: "2026-12-05T09:00:00+08:00",
  },

  theme: {
    colors: {
      snowWhite: "#F9FCFF",
      iceBlue: "#EAF6FF",
      crystalBlue: "#B9E2F5",
      silver: "#DDE5EF",
      blushPink: "#F7D5E3",
      fairytalePink: "#E998AF",
      deepBlue: "#294867",
    },
    castleBackgroundUrl: "/src/assets/images/frozen_castle_fairytale_bg_1792606609330.jpg",
  },

  characterArtwork: {
    olafEnvelope: "/images/characters/olaf-envelope.png",
    olafGift: "/images/characters/olaf-gift.png",
    olafWaving: "/assets/aistudio/Olaf_Hi_b2647508.png",
    elsaMusic: "/assets/aistudio/Elsa_9319f7d3.png",
    annaCake: "/assets/aistudio/Anna_bb8e4e14.png",
  },

  music: {
    audioPath: "/audio/baby-az-music.mp3",
    fallbackAudioPath: "/assets/aistudio/Do_You_Want_To_Build_A_Snowman_Karaoke_Instrumental_Frozen_3c6ce7f4.mp3",
    title: "Do You Want to Build a Snowman?",
    subtitle: "Magical Instrumental",
    defaultVolume: 0.3,
    loop: true,
  },

  venues: {
    christening: {
      title: "The Sacred Blessing",
      churchName: "Our Lady Queen of Peace Parish",
      name: "Our Lady Queen of Peace Parish",
      branch: "Queen's Row West",
      date: "December 5, 2026",
      time: "9:00 AM – 11:00 AM",
      address: "Queen's Row West, Bacoor City, Cavite",
      mapUrl: "https://maps.app.goo.gl/JfL1mQD5CjAhroPD8",
      mapsUrl: "https://maps.app.goo.gl/JfL1mQD5CjAhroPD8",
      photoUrl: "/images/venues/church.png",
      image: "/images/venues/church.png",
      imageAlt: "Actual photograph of Our Lady Queen of Peace Parish",
      badge: "Holy Sacrament",
      accent: "ice-blue",
      details: "Please arrive 15 minutes before 9:00 AM for registration and seating of sponsors and beloved guests.",
    },
    birthday: {
      title: "Baby AZ's Royal Birthday Celebration",
      venueName: "Jollibee Molino Bayanan",
      name: "Jollibee Molino Bayanan",
      branch: "Molino Bayanan",
      partyTheme: "Jollibee Fairytale Land",
      themeName: "Jollibee Fairytale Land",
      date: "December 5, 2026",
      time: "12:30 PM – 3:00 PM",
      address: "409 Molino Road, Bacoor, Cavite, Philippines",
      mapUrl: "https://maps.app.goo.gl/8AcWYJXASrsZs2eJ9",
      mapsUrl: "https://maps.app.goo.gl/8AcWYJXASrsZs2eJ9",
      photoUrl: "/images/venues/jollibee-bayanan.jpg",
      image: "/images/venues/jollibee-bayanan.jpg",
      imageAlt: "Actual photograph of Jollibee Molino Bayanan",
      badge: "Fairytale Party",
      accent: "fairytale-pink",
      details: "Join us for delightful games, festive Jollibee meals, royal mascot surprises, and sweet birthday cake!",
    },
  },

  schedule: [
    {
      time: "9:00 AM – 11:00 AM",
      title: "Christening Ceremony",
      description: "Our Lady Queen of Peace Parish",
      location: "Our Lady Queen of Peace Parish",
      iconType: "church",
    },
    {
      time: "11:00 AM – 12:00 PM",
      title: "Family & Friends Picture Taking",
      description: "At the church after the Christening",
      location: "Church Altar & Grounds",
      iconType: "camera",
    },
    {
      time: "12:00 PM – 12:30 PM",
      title: "Travel to Birthday Venue",
      description: "Transfer to Jollibee Molino Bayanan",
      location: "Transfer to Jollibee Molino Bayanan",
      iconType: "car",
    },
    {
      time: "12:30 PM – 3:00 PM",
      title: "Baby AZ's Royal Birthday Party",
      description: "Jollibee Fairytale Land",
      location: "Jollibee Fairytale Land, Molino Bayanan",
      iconType: "party",
    },
  ] as ScheduleItem[],

  gallerySection: {
    heading: "Baby AZ's Magical Moments",
    subtitle: "Little moments, precious memories, and a whole lot of love.",
  },

  gallery: [
    {
      id: "photo-1",
      url: "/images/gallery/baby-az-01.jpg",
      title: "Little Snow Princess",
      caption: "Baby AZ in her adorable royal blue tutu outfit & matching headband",
    },
    {
      id: "photo-2",
      url: "/images/gallery/baby-az-02.jpg",
      title: "Storytime Wonder",
      caption: "Baby AZ curiously exploring her colorful nursery storybook",
    },
    {
      id: "photo-3",
      url: "/images/gallery/baby-az-03.jpg",
      title: "Radiant Smiles",
      caption: "Pure happiness and cheerful giggles in her high chair",
    },
    {
      id: "photo-4",
      url: "/images/gallery/baby-az-04.jpg",
      title: "Crocheted Sunshine",
      caption: "Sweetest smile wearing her handcrafted sunflower hat and dress",
    },
    {
      id: "photo-5",
      url: "/images/gallery/baby-az-05.jpg",
      title: "Fairytale Snow White",
      caption: "Our little storybook princess dressed in royal colors",
    },
    {
      id: "photo-6",
      url: "/images/gallery/baby-az-06.jpg",
      title: "Precious Joy in Pink",
      caption: "Spreading smiles with her baby spoon and bow",
    },
    {
      id: "photo-7",
      url: "/images/gallery/baby-az-07.jpg",
      title: "Poolside Adventures",
      caption: "Looking back with wonder during a breezy outdoor day",
    },
    {
      id: "photo-8",
      url: "/images/gallery/baby-az-08.jpg",
      title: "Turquoise Sparkle",
      caption: "Looking up with bright eyes and tiny turquoise blossoms",
    },
  ] as GalleryPhoto[],

  wishlist: {
    enabled: true,
    smallHeading: "A LITTLE SOMETHING FOR OUR PRINCESS",
    heading: "Baby AZ's Little Wishlist",
    subtitle: "GIFT REGISTRY",
    message:
      "Your presence and prayers are the greatest gifts of all. " +
      "But if you'd like to surprise our little princess with " +
      "something special, we've prepared a little wishlist " +
      "of things Baby AZ would love and use as she grows.",
    signature: "With love, Mommy Chaye & Daddy Jerome",
    buttonText: "VIEW BABY AZ'S WISHLIST",
    pageUrl: "/wishlist",
    status: "draft",
    characterImage: "/images/characters/olaf-gift.png",
    items: [
      {
        id: "board-books",
        name: "Baby Board Books",
        category: "Books & Early Learning",
        description: "Durable touch-and-feel books, bedtime nursery rhymes, and colorful sensory storybooks for baby's early reading.",
        sizeOrSpecs: "Chunky cardboard pages suitable for 1+ years",
        storeName: "Shopee / Lazada / Fully Booked",
        shoppingUrl: "",
        iconEmoji: "📚",
      },
      {
        id: "learning-toys",
        name: "Stacking & Learning Toys",
        category: "Toys & Development",
        description: "Montessori stacking cups, soft silicone building blocks, or interactive shape sorters to develop motor skills.",
        sizeOrSpecs: "BPA-free & non-toxic materials",
        storeName: "Shopee / Lazada / Toys 'R' Us",
        shoppingUrl: "",
        iconEmoji: "🧩",
      },
      {
        id: "clothes-pajamas",
        name: "Baby Clothes & Pajamas",
        category: "Apparel & Comfort",
        description: "Soft breathable cotton onesies, cozy sleepsuits, or cute fairytale dresses for playtime and outings.",
        sizeOrSpecs: "Size 12–18 Months or 18–24 Months",
        storeName: "Shopee / Lazada / Uniqlo Baby",
        shoppingUrl: "",
        iconEmoji: "👗",
      },
      {
        id: "diapers",
        name: "Diapers (Tape or Pants)",
        category: "Daily Essentials",
        description: "Gentle hypoallergenic baby tape or pants diapers for day and night comfort.",
        sizeOrSpecs: "Size Large (L) or Extra Large (XL)",
        storeName: "MamyPoko / Pampers / Huggies / Shopee",
        shoppingUrl: "",
        iconEmoji: "👶",
      },
      {
        id: "feeding-essentials",
        name: "Toddler Feeding Essentials",
        category: "Mealtime",
        description: "Silicone suction divider plates, spill-proof trainer straw cups, and soft feeding utensils.",
        sizeOrSpecs: "Food-grade silicone, microwave & dishwasher safe",
        storeName: "Shopee / Lazada / Mothercare",
        shoppingUrl: "",
        iconEmoji: "🥣",
      },
      {
        id: "plush-toys",
        name: "Baby-Safe Plush & Comfort Toys",
        category: "Snuggles & Play",
        description: "Ultra-soft cuddle plushies, gentle sleeping companions, or cute snowman / fairytale stuffed toys.",
        sizeOrSpecs: "Embroidered details (no small chokeable buttons)",
        storeName: "Shopee / Lazada / Toy Kingdom",
        shoppingUrl: "",
        iconEmoji: "🧸",
      },
    ] as WishlistItem[],
  },

  dressCode: {
    title: "Dress for a Winter Fairytale",
    description: "We invite you to celebrate in royal fairytale style or comfy smart-casual attire. Suggested colors:",
    colors: [
      { name: "Ice Blue", hex: "#B9E2F5", border: "#7bc3eb" },
      { name: "Snow White", hex: "#F9FCFF", border: "#DDE5EF" },
      { name: "Silver", hex: "#DDE5EF", border: "#9fb0c6" },
      { name: "Blush Pink", hex: "#F7D5E3", border: "#e8a4be" },
      { name: "Fairytale Pink", hex: "#E998AF", border: "#d76b88" },
    ],
    note: "These colors are completely optional suggestions — your comfortable presence is what matters most!",
  },

  giftNote: {
    title: "Your Presence Is the Greatest Gift",
    quote: "Your love, prayers, and presence mean the world to our family. Gifts are appreciated but never expected.",
    subtext: "If you wish to honor Baby AZ with a token of love, a monetary gift toward her future savings or a small toy/book from her wishlist is warmly received.",
  },

  contacts: {
    organizer: "Mommy Chaye & Daddy Jerome",
    phone: "+63 917 123 4567",
    email: "jeromebuere.techva@gmail.com",
    messengerUrl: "https://m.me/chaye.jerome",
  },

  rsvp: {
    deadlineText: "Please RSVP by November 20, 2026",
    deadlineDate: "November 20, 2026",
    maxAttendeesPerSubmission: 8,
    disclaimer: "By submitting, you agree to share your name and attendance count with Baby AZ's family for party catering purposes.",
  },
};
